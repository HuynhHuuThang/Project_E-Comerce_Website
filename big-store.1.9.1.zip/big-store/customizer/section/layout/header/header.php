<?php
/**
 * Header Options for  Big StoreTheme.
 *
 * @package      Big Store
 * @author       Big Store
 * @since        Big Store1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'big-store-abv-header-clr';
$wp_customize->get_control( 'header_image' )->priority = 1;
